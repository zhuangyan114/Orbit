---
name: ozone-for-vscode-config-skill
description: Configure and verify an STM32 firmware workspace for Ozone for VS Code in one pass. Use when Codex must create or validate CMake/ARM toolchain settings, .vscode/launch.json, Ozone debug settings, MCU Debug RTOS Views integration, Ozone MCP server setup, RTT logging, P-RTLog tokenized RTT settings when the target code uses P-RTLog, and explain how to change related configuration options.
---

# Ozone For VS Code Config

## Goal

Configure the current STM32 firmware workspace so one Ozone for VS Code debug launch works end to end. If a configuration already exists, validate and merge missing pieces instead of replacing user choices.

Read `references/configuration-details.md` when writing concrete JSON, CMake, MCP, RTOS, RTT, or P-RTLog settings.

## One-Pass Workflow

1. Identify the workspace being configured.
   - Treat the current folder as the target firmware project when it contains `CMakeLists.txt`, `.ioc`, `Core/`, `Src/`, `Inc/`, or an ELF/AXF under `build/`.
   - If the current folder is the Ozone extension repo, ask for the firmware project path before editing project configuration.
   - Do not edit global user settings unless the user explicitly asks; prefer workspace `.vscode/` files.

2. Audit before editing.
   - Inspect `.vscode/settings.json`, `.vscode/launch.json`, `.vscode/tasks.json`, `CMakePresets.json`, `CMakeUserPresets.json`, `CMakeLists.txt`, toolchain files, and build output.
   - Find target metadata from existing files first: MCU device, ELF/AXF path, SVD path, interface, speed, RTOS, RTT channel, and build type.
   - Derive chip-specific values from the actual project, not examples or prior projects. Confirm the exact MCU from `.ioc`, startup file, linker script, CMake definitions, SVD filename, and any known-good project before writing `device`, `deviceName`, SVD paths, preprocessor defines, or linker/startup references.
   - Detect P-RTLog usage before enabling it. Look for project references such as `P_RTLOG`, `PRTLOG`, `P-RTLog`, `PW_LOG`, `PW_TOKENIZE`, `pw_tokenizer`, `.pw_tokenizer.entries`, or P-RTLog include paths.

3. Configure CMake and toolchain.
   - Preserve existing presets/toolchain files when present.
   - If CMake exists but no ARM GCC toolchain is configured, add a workspace-local toolchain file or preset using `arm-none-eabi-gcc`, `arm-none-eabi-g++`, `arm-none-eabi-objcopy`, `arm-none-eabi-size`, and `CMAKE_TRY_COMPILE_TARGET_TYPE=STATIC_LIBRARY`.
   - Set VS Code CMake Tools workspace settings only when they are absent or incomplete.

4. Configure Ozone launch.
   - Ensure `.vscode/launch.json` has a configuration with `"type": "ozone"` and `"request": "launch"`.
   - Set `program`, `device`, `deviceName`, `interface`, `speedKHz`, `svdFile`/`svdPath`, `rtos`, RTT fields, and P-RTLog fields.
   - Write chip-specific fields for the actual board. Do not copy placeholder MCU names such as `STM32F407VG` when the project uses `STM32F407IG`.
   - Prefer launch-level values for project-specific choices; use `ozone.*` settings as defaults shared by all Ozone launches.

5. Configure MCU Debug RTOS Views integration.
   - Ensure workspace settings arrays include `"ozone"` for `memory-view.trackDebuggers`, `mcu-debug.rtos-views.trackDebuggers`, and `mcu-debug.debug-tracker-vscode.trackDebuggers`.
   - Set `ozone.defaultRtos` or launch `rtos` to `"FreeRTOS"` only when the project uses FreeRTOS or the user requests it.
   - Verify launch `device` and `deviceName` match the real MCU and SVD family. Do not guess from a template; compare against the `.ioc`, CMake definitions, existing working project config, or the SVD filename.
   - If FreeRTOS is detected, check `FreeRTOSConfig.h` for trace/runtime macros, stack high-address recording, and runtime-stat hook mappings.
   - If `portCONFIGURE_TIMER_FOR_RUN_TIME_STATS` or `portGET_RUN_TIME_COUNTER_VALUE` is mapped to project functions, verify those functions are implemented and do not return a constant. Empty DWT/CYCCNT hooks can make RTOS Views show `????`.
   - Report missing firmware-side defines or empty runtime-stat hooks. Edit generated files only when the project has a safe user-code block and the user requested firmware changes.

6. Configure RTT and P-RTLog.
   - Keep plain RTT enabled by default unless the project explicitly disables it.
   - Enable `pRtLogEnabled` only when P-RTLog/tokenized logging is detected or the user asks for it.
   - When P-RTLog is enabled, verify the ELF/AXF contains `.pw_tokenizer.entries`; if it does not, report that firmware/linker configuration must preserve the token section.

7. Configure MCP if missing.
   - Verify the Ozone extension MCP server path points to `mcp/ozone-mcp-server.js` and that its dependencies are installed.
   - Add an `ozone` MCP server entry to the user's chosen MCP client config only when the target config file is known or the user asks for a specific client.
   - Use `OZONE_PLUGIN_API_ENDPOINT_FILE` pointing at the VS Code global storage endpoint file for `ozone-debug.ozone-for-vscode`.

8. Validate.
   - Validate JSON/JSONC syntax for edited `.vscode` files.
   - Confirm required executables are discoverable: `cmake`, `ninja` or selected generator, `arm-none-eabi-gcc`, `arm-none-eabi-objdump`, `node`, and J-Link/JLink DLL when applicable.
   - Run a non-destructive CMake configure/build check when the project supports it.
   - For MCP, validate that `node <extension-root>/mcp/ozone-mcp-server.js` can load dependencies; endpoint availability requires VS Code with the Ozone extension active.

9. Report changes and how to change them later.
   - List files changed and values chosen.
   - State any assumptions that could not be verified, especially MCU device, SVD path, RTOS type, RTT buffer, and P-RTLog token section.
   - Include concise instructions for changing common options: device, ELF path, SVD, RTOS, RTT target, P-RTLog enable/root, watch/timeline sampling, and MCP endpoint.

## Editing Rules

- Merge JSON arrays without duplicating `"ozone"`.
- Preserve existing debug configurations and add a new Ozone configuration if none exists.
- Prefer `${workspaceFolder}` paths in committed workspace files.
- Do not hard-code a user-specific extension repo path in a target project unless no installed extension/MCP path can be resolved.
- Treat `.vscode/*.json` as JSONC-capable VS Code files; preserve comments when possible.
- Do not enable P-RTLog for ordinary text RTT projects.
