# Ozone For VS Code Configuration Details

Use these details when applying `ozone-for-vscode-config-skill`.

## Workspace Settings

Minimum `.vscode/settings.json` values for Ozone integration:

```json
{
  "cmake.configureOnOpen": true,
  "cmake.buildDirectory": "${workspaceFolder}/build/${buildType}",
  "memory-view.trackDebuggers": ["ozone"],
  "mcu-debug.rtos-views.trackDebuggers": ["ozone"],
  "mcu-debug.debug-tracker-vscode.trackDebuggers": ["ozone"],
  "ozone.defaultDevice": "STM32F407IG",
  "ozone.defaultInterface": "SWD",
  "ozone.defaultSpeed": 4000,
  "ozone.defaultProgram": "${workspaceFolder}/build/Debug/frame.elf",
  "ozone.defaultSvdFile": "",
  "ozone.defaultRtos": "",
  "ozone.rttLogEnabled": true,
  "ozone.rttBufferIndex": 0,
  "ozone.rttPollIntervalMs": 50,
  "ozone.rttReadSize": 4096,
  "ozone.rttControlBlockAddress": "",
  "ozone.rttStripAnsi": true,
  "ozone.rttLogTarget": "terminal",
  "ozone.pRtLogEnabled": false,
  "ozone.pRtLogRoot": "D:\\STM32\\tool\\P-RTLog",
  "ozone.watchPollIntervalMs": 500,
  "ozone.timelineSampleIntervalMs": 0.2,
  "ozone.timelineSendIntervalMs": 16
}
```

Add only the fields needed for the project. Launch configuration values override `ozone.*` defaults.

## Launch Configuration

Preferred `.vscode/launch.json` shape:

```json
{
  "version": "0.2.0",
  "configurations": [
    {
      "type": "ozone",
      "request": "launch",
      "name": "Ozone: Debug STM32",
      "program": "${workspaceFolder}/build/Debug/frame.elf",
      "device": "STM32F407IG",
      "deviceName": "STM32F407IG",
      "interface": "SWD",
      "speedKHz": 4000,
      "svdFile": "${workspaceFolder}/STM32F407.svd",
      "svdPath": "${workspaceFolder}/STM32F407.svd",
      "rtos": "FreeRTOS",
      "rttLogEnabled": true,
      "rttBufferIndex": 0,
      "rttPollIntervalMs": 50,
      "rttReadSize": 4096,
      "rttControlBlockAddress": "",
      "rttStripAnsi": true,
      "rttLogTarget": "terminal",
      "pRtLogEnabled": false,
      "pRtLogRoot": "D:\\STM32\\tool\\P-RTLog"
    }
  ]
}
```

Change these fields for common cases:

| Field | Use |
| --- | --- |
| `program` / `ozone.defaultProgram` | ELF/AXF path. Prefer `${workspaceFolder}/build/.../*.elf`. |
| `device`, `deviceName` / `ozone.defaultDevice` | J-Link device name and external MCU view alias. Keep both equal unless there is a known alias difference. |
| `interface` / `ozone.defaultInterface` | `SWD` or `JTAG`. |
| `speedKHz` / `ozone.defaultSpeed` | J-Link speed. Use `4000` as a conservative default. |
| `svdFile`, `svdPath` / `ozone.defaultSvdFile` | CMSIS-SVD path for Peripheral Viewer. Set both aliases for compatibility. |
| `rtos` / `ozone.defaultRtos` | RTOS type for RTOS Views, commonly `FreeRTOS`. Leave empty when no RTOS is used. |
| `rttLogTarget` | `terminal`, `debugConsole`, or `both`. |
| `pRtLogEnabled` / `ozone.pRtLogEnabled` | Enable only for tokenized P-RTLog RTT frames. |

## Chip-Specific Values

Always write configuration for the actual chip in the current firmware project. Treat examples in this skill as shapes, not values to copy.

Confirm the MCU from at least two project-local sources before writing chip-specific settings:

- `.ioc` file fields such as `Mcu.Name`, `Mcu.Family`, or package.
- Startup file name, such as `startup_stm32f407xx.s`.
- Linker script name and memory map, such as `STM32F407XX_FLASH.ld`.
- CMake compile definitions, such as `STM32F407xx`.
- Existing project-local SVD filename or a known-good sibling project.
- Existing working debug config for the same board.

Keep these values consistent with that actual chip:

- Ozone launch `device` and `deviceName`.
- `ozone.defaultDevice`.
- `svdFile`, `svdPath`, and `ozone.defaultSvdFile`.
- CMake/IDE preprocessor definitions.
- Startup file and linker script references.

Do not copy a board/package-specific value from another project just because it launches. A VG/IG mismatch can make Peripheral Viewer and RTOS Views partially work while selected fields still show `????`.

## CMake Toolchain

If no existing ARM GCC toolchain exists, create `cmake/gcc-arm-none-eabi.cmake`:

```cmake
set(CMAKE_SYSTEM_NAME Generic)
set(CMAKE_SYSTEM_PROCESSOR arm)
set(CMAKE_TRY_COMPILE_TARGET_TYPE STATIC_LIBRARY)

find_program(ARM_GCC arm-none-eabi-gcc REQUIRED)
get_filename_component(ARM_TOOLCHAIN_BIN_DIR "${ARM_GCC}" DIRECTORY)

set(CMAKE_C_COMPILER "${ARM_TOOLCHAIN_BIN_DIR}/arm-none-eabi-gcc.exe")
set(CMAKE_CXX_COMPILER "${ARM_TOOLCHAIN_BIN_DIR}/arm-none-eabi-g++.exe")
set(CMAKE_ASM_COMPILER "${ARM_TOOLCHAIN_BIN_DIR}/arm-none-eabi-gcc.exe")
set(CMAKE_OBJCOPY "${ARM_TOOLCHAIN_BIN_DIR}/arm-none-eabi-objcopy.exe")
set(CMAKE_SIZE "${ARM_TOOLCHAIN_BIN_DIR}/arm-none-eabi-size.exe")
```

On non-Windows systems, drop the `.exe` suffixes.

If the project uses presets, add or merge:

```json
{
  "version": 3,
  "configurePresets": [
    {
      "name": "debug",
      "displayName": "Debug",
      "generator": "Ninja",
      "binaryDir": "${sourceDir}/build/Debug",
      "cacheVariables": {
        "CMAKE_BUILD_TYPE": "Debug",
        "CMAKE_TOOLCHAIN_FILE": "${sourceDir}/cmake/gcc-arm-none-eabi.cmake",
        "CMAKE_EXPORT_COMPILE_COMMANDS": "ON"
      }
    }
  ],
  "buildPresets": [
    {
      "name": "debug",
      "configurePreset": "debug"
    }
  ]
}
```

If the project already uses STM32CubeMX or another generated CMake layout, prefer updating the existing preset or VS Code CMake Tools settings instead of rewriting `CMakeLists.txt`.

## RTOS Views

RTOS Views require three layers to agree:

1. VS Code external-view tracker settings.
2. Ozone launch metadata that matches the target MCU, ELF, SVD, and RTOS.
3. Firmware-side FreeRTOS symbols, trace macros, and runtime-stat hooks.

Do not stop after adding tracker settings. A project can launch while RTOS Views still show `????` when the MCU/SVD is copied from the wrong board, stack high-address recording is missing, or runtime-stat hooks are empty.

Workspace settings needed for external MCU views:

```json
{
  "memory-view.trackDebuggers": ["ozone"],
  "mcu-debug.rtos-views.trackDebuggers": ["ozone"],
  "mcu-debug.debug-tracker-vscode.trackDebuggers": ["ozone"],
  "ozone.defaultRtos": "FreeRTOS"
}
```

Launch fields that must be project-specific:

```json
{
  "type": "ozone",
  "request": "launch",
  "program": "${workspaceFolder}/build/Debug/frame.elf",
  "device": "STM32F407IG",
  "deviceName": "STM32F407IG",
  "svdFile": "${workspaceFolder}/STM32F407.svd",
  "svdPath": "${workspaceFolder}/STM32F407.svd",
  "rtos": "FreeRTOS"
}
```

Rules:

- Keep `device` and `deviceName` equal to the actual J-Link device unless there is a verified alias difference.
- Keep `svdFile` and `svdPath` pointing at an SVD that matches the MCU family/package used by the firmware. Do not leave a copied `STM32F407VG` device value when the working project uses `STM32F407IG`.
- Prefer `${workspaceFolder}` paths for project-local SVD files. Absolute SEGGER SVD paths are acceptable only when no project SVD exists.
- Verify `program` points at the ELF/AXF built from the same workspace. RTOS Views need debug symbols from the active ELF.

FreeRTOS firmware-side macros required or strongly expected by RTOS Views:

```c
#define configUSE_TRACE_FACILITY              1
#define configRECORD_STACK_HIGH_ADDRESS       1
#define configGENERATE_RUN_TIME_STATS         1
#define configUSE_STATS_FORMATTING_FUNCTIONS  1
#define portCONFIGURE_TIMER_FOR_RUN_TIME_STATS()  (CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk, DWT->CTRL |= DWT_CTRL_CYCCNTENA_Msk)
#define portGET_RUN_TIME_COUNTER_VALUE()           (DWT->CYCCNT)
```

Some CubeMX projects map the runtime-stat hooks to functions instead of inline macros:

```c
#define portCONFIGURE_TIMER_FOR_RUN_TIME_STATS configureTimerForRunTimeStats
#define portGET_RUN_TIME_COUNTER_VALUE getRunTimeCounterValue
```

When these mappings exist, verify the functions are implemented in `freertos.c` or another compiled source file:

```c
void configureTimerForRunTimeStats(void)
{
    CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;
    DWT->CTRL |= DWT_CTRL_CYCCNTENA_Msk;
    DWT->CYCCNT = 0;
}

unsigned long getRunTimeCounterValue(void)
{
    return DWT->CYCCNT;
}
```

Treat these as failures to report or fix:

- `configRECORD_STACK_HIGH_ADDRESS` is missing.
- `portCONFIGURE_TIMER_FOR_RUN_TIME_STATS` maps to an empty function.
- `portGET_RUN_TIME_COUNTER_VALUE` returns `0` or another constant.
- The launch config uses a device copied from a different target, such as `STM32F407VG` while the working project and SVD use `STM32F407IG`.

Known local comparison: `D:\STM32\RoboMaster\26Lao_ShaoBin\Down-cmake` is the working RTOS Views reference. `D:\STM32\RoboMaster\26Lao_ShaoBin\Up` previously showed all `????` after agent configuration because its RTOS View configuration was incomplete; compare these projects before changing similar RoboMaster workspaces.

Do not blindly insert these into generated files. If `FreeRTOSConfig.h` or `freertos.c` has user-code blocks, add them there only when it is safe; otherwise report the exact missing macros or empty hook functions.

## RTT And P-RTLog

Plain SEGGER RTT:

```json
{
  "ozone.rttLogEnabled": true,
  "ozone.rttBufferIndex": 0,
  "ozone.rttLogTarget": "terminal"
}
```

P-RTLog tokenized RTT:

```json
{
  "ozone.pRtLogEnabled": true,
  "ozone.pRtLogRoot": "D:\\STM32\\tool\\P-RTLog",
  "ozone.rttLogEnabled": true,
  "ozone.rttBufferIndex": 0,
  "ozone.rttLogTarget": "terminal"
}
```

Enable P-RTLog only when code or build artifacts indicate tokenized logging. The Ozone decoder reads `.pw_tokenizer.entries` from the current ELF/AXF and decodes RTT binary frames formatted as `[2-byte length][token + encoded args]`.

Verify token section:

```powershell
arm-none-eabi-objdump -h .\build\Debug\frame.elf | Select-String ".pw_tokenizer.entries"
```

If the section is missing, keep `pRtLogEnabled` false or report that the firmware/linker build must retain `.pw_tokenizer.entries`.

## MCP Setup

The extension ships an MCP server at:

```text
<ozone-extension-root>\mcp\ozone-mcp-server.js
```

Ensure dependencies exist:

```powershell
Push-Location "<ozone-extension-root>\mcp"
npm install
Pop-Location
```

MCP server entry:

```json
{
  "mcpServers": {
    "ozone": {
      "command": "node",
      "args": [
        "C:\\path\\to\\ozone-for-vscode\\mcp\\ozone-mcp-server.js"
      ],
      "env": {
        "OZONE_PLUGIN_API_ENDPOINT_FILE": "C:\\Users\\<user>\\AppData\\Roaming\\Code\\User\\globalStorage\\ozone-debug.ozone-for-vscode\\plugin-api-endpoint.json"
      }
    }
  }
}
```

The endpoint file is created by the VS Code extension after activation. If it is missing, open VS Code with the Ozone extension installed and start or activate the extension before testing MCP target tools.

## Validation Commands

Use commands appropriate to the current shell and project:

```powershell
code --list-extensions | Select-String "ozone-debug.ozone-for-vscode|mcu-debug|rtos"
Get-Command cmake
Get-Command ninja
Get-Command arm-none-eabi-gcc
Get-Command arm-none-eabi-objdump
Get-Command node
Test-Path "C:\Program Files\SEGGER\JLink\JLink_x64.dll"
cmake --preset debug
cmake --build --preset debug
```

For edited JSON without comments:

```powershell
Get-Content .vscode\settings.json -Raw | ConvertFrom-Json | Out-Null
Get-Content .vscode\launch.json -Raw | ConvertFrom-Json | Out-Null
```

For JSONC files with comments, use VS Code or a JSONC-aware parser; do not remove comments just to validate.

## Final Report Template

Report:

- Files changed.
- CMake preset/toolchain selected.
- Ozone launch name and program path.
- Device, interface, speed, SVD, RTOS.
- RTT and P-RTLog status, including whether `.pw_tokenizer.entries` was found.
- MCP server path and endpoint path.
- Commands run and their result.
- Remaining manual steps, such as reloading VS Code or adding FreeRTOS macros.
